#include "messages.hpp"


int Trade::GetLastSize() const {
    //TODO: Implement ME?
    return 0;
}

float Trade::GetLastPrice() const {
    //TODO: Implement ME?
    return 0;
}

std::string Trade::GetSymbol() const {
    //TODO: IMPLEMENT ME!
    return "";
}

int Quote::GetBidSize(){
    return 0.0;
}

float Quote::GetBidPrice(){
    return 0.0;
}

int Quote::GetAskSize(){
    return 0;
}

float Quote::GetAskPrice(){
    return 0;
}

std::string Quote::GetSymbol(){
    return "";
}


